// Cycle: connected up to 23 hours, disconnected 4 minutes, repeat.
const host=process.env.BOT_HOST,port=Number(process.env.BOT_PORT),edition=process.env.BOT_EDITION||'java',username=process.env.BOT_USERNAME||'SAWANTH_HERE',version=process.env.BOT_VERSION||undefined,auth=process.env.BOT_AUTH||'offline';
const SESSION=23*60*60*1000,BREAK=4*60*1000;let stopping=false,client=null,timer=null;
const sleep=ms=>new Promise(resolve=>{timer=setTimeout(resolve,ms)});
function closeClient(c){try{if(edition==='java')c?.quit('Scheduled reconnect');else c?.disconnect('Scheduled reconnect')}catch{try{c?.close()}catch{}}}
function once(){return new Promise(resolve=>{let done=false,joined=false,timeout;let c;
 const finish=m=>{if(done)return;done=true;clearTimeout(timeout);if(timer)clearTimeout(timer);if(client===c)client=null;console.log(m);resolve()};
 try{
 if(edition==='java'){const mf=require('mineflayer');let opts={host,port,username,auth:auth==='microsoft'?'microsoft':'offline'};if(version)opts.version=version;c=mf.createBot(opts);client=c;c.once('login',()=>{joined=true;clearTimeout(timeout);console.log('Java connected '+host+':'+port);timer=setTimeout(()=>{console.log('23h reached; disconnecting');closeClient(c);finish('Scheduled disconnect')},SESSION)});c.on('spawn',()=>console.log('Spawned'));c.on('kicked',x=>console.log('Kicked '+JSON.stringify(x)));c.on('error',e=>console.log('Java error '+e.message));c.on('end',x=>finish('Java ended '+(x||'')))}
 else if(edition==='bedrock'){const bp=require('bedrock-protocol');let opts={host,port,username,offline:true};if(version)opts.version=version;c=bp.createClient(opts);client=c;c.once('join',()=>{joined=true;clearTimeout(timeout);console.log('Bedrock joined '+host+':'+port);timer=setTimeout(()=>{console.log('23h reached; disconnecting');closeClient(c);finish('Scheduled disconnect')},SESSION)});c.on('spawn',()=>console.log('Spawned'));c.on('error',e=>console.log('Bedrock error '+e.message));c.on('close',()=>finish('Bedrock closed'))}
 else return finish('Unsupported edition');
 timeout=setTimeout(()=>{if(!joined){closeClient(c);finish('Connection timed out')}} ,60000);
 }catch(e){finish('Client error '+e.message)}
})}
async function main(){if(!host||!Number.isInteger(port)||port<1||port>65535)throw Error('Invalid host or port');console.log('Cycle: 23h online, 4m break.');while(!stopping){await once();if(stopping)break;console.log('Waiting 4 minutes before retry');await sleep(BREAK)}}
function shutdown(){stopping=true;if(timer)clearTimeout(timer);closeClient(client);setTimeout(()=>process.exit(0),500)}
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);main().catch(e=>{console.error(e);process.exit(1)});
