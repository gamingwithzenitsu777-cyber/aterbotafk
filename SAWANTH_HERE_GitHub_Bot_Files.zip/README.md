# SAWANTH_HERE Minecraft Bot Panel

## Run
Requires Node.js 20+.
1. Extract this repository.
2. Run `npm install`
3. Run `npm start`
4. Open `http://localhost:3000`
5. Set IP, port and edition; save, then Start.

The dashboard stores settings in `data.json`. It runs a worker that cycles up to 23 hours connected, waits 4 minutes after disconnect, then retries.

## Hosting
Deploy the complete repository to an always-on Node.js host that allows outbound Minecraft traffic and persistent processes. Set start command `npm start`; use the platform's assigned `PORT`. GitHub stores the code but does not run it by itself.

## Protocol/auth notes
Java uses Mineflayer; Bedrock uses bedrock-protocol. This is a basic connection/presence bot, not a gameplay AI. Bedrock compatibility and authentication depend on server/proxy/version. Microsoft Java login may require an interactive auth flow. Never enter passwords into this panel. Check server rules and get permission before running automated clients.

## Security
This starter has no dashboard login. Keep it private; add authentication and HTTPS before exposing it publicly.
