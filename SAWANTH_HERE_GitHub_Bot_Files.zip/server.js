const express=require('express'),path=require('path'),fs=require('fs'),{spawn}=require('child_process');
const app=express(),PORT=process.env.PORT||3000,FILE=path.join(__dirname,'data.json');
const defaults={host:'',port:25565,edition:'java',username:'SAWANTH_HERE',version:'',auth:'offline'};
let config=(()=>{try{return {...defaults,...JSON.parse(fs.readFileSync(FILE))}}catch{return {...defaults}}})(),child=null,status='stopped',logs=[];
function log(s){logs.push(new Date().toISOString()+' '+s);if(logs.length>300)logs.shift();console.log(s)}
app.use(express.json());app.use(express.static(path.join(__dirname,'public')));
app.get('/api/config',(_,r)=>r.json(config));
app.put('/api/config',(q,r)=>{let b=q.body||{},p=Number(b.port),u=String(b.username||'SAWANTH_HERE').trim();if(!String(b.host||'').trim())return r.status(400).json({error:'Server hostname required'});if(!Number.isInteger(p)||p<1||p>65535)return r.status(400).json({error:'Port must be 1–65535'});if(!['java','bedrock'].includes(b.edition))return r.status(400).json({error:'Choose Java or Bedrock'});if(!u||u.length>16)return r.status(400).json({error:'Username must be 1–16 characters'});config={host:String(b.host).trim(),port:p,edition:b.edition,username:u,version:String(b.version||'').trim(),auth:b.auth==='microsoft'?'microsoft':'offline'};fs.writeFileSync(FILE,JSON.stringify(config,null,2));log('Configuration saved.');r.json(config)});
app.get('/api/status',(_,r)=>r.json({status,config,logs}));
function start(){if(child)throw Error('Already running');if(!config.host)throw Error('Save server hostname first');let env={...process.env,BOT_HOST:config.host,BOT_PORT:String(config.port),BOT_EDITION:config.edition,BOT_USERNAME:config.username,BOT_VERSION:config.version,BOT_AUTH:config.auth};child=spawn(process.execPath,[path.join(__dirname,'bot.js')],{cwd:__dirname,env});status='running';log('Bot worker launched.');child.stdout.on('data',d=>String(d).trim().split('\\n').forEach(log));child.stderr.on('data',d=>String(d).trim().split('\\n').forEach(x=>log('ERROR '+x)));child.on('exit',c=>{child=null;status='stopped';log('Worker exited '+c)})}
function stop(){if(child){child.kill('SIGTERM');child=null}status='stopped';log('Stop requested')}
app.post('/api/start',(_,r)=>{try{start();r.json({ok:true})}catch(e){r.status(400).json({error:e.message})}});
app.post('/api/stop',(_,r)=>{stop();r.json({ok:true})});
app.post('/api/restart',(_,r)=>{stop();try{start();r.json({ok:true})}catch(e){r.status(400).json({error:e.message})}});
app.listen(PORT,'0.0.0.0',()=>log('Dashboard listening on '+PORT));
process.on('SIGTERM',()=>{stop();process.exit(0)});process.on('SIGINT',()=>{stop();process.exit(0)});
